/*  1620 final project
*  
*   Wenchao He
*
*   student ID:201450150
*   
*/
#include "mbed.h"

BufferedSerial pc(USBTX, USBRX,9600); //establish serial communications between PC and NUCLEO

PwmOut redled(PB_3);      //define PWM pins for RGB LED
PwmOut greenled(PB_5);
PwmOut blueled(PB_4);
PwmOut buzzer(PA_15);
BusOut leds_bus(PC_0, PC_1, PB_0, PA_4);

AnalogIn pot1(PA_5);  //input for the potentiometer.
AnalogIn TMP(PC_3); //TEMP Sensor pin
AnalogIn FSR(PA_1); //Force sensor pin

DigitalIn button1(PC_10); //accidendtial break.

#define NOTE_C4  262    //note for BUZZER;
#define NOTE_D4  294
#define NOTE_E4  330

const int C_major_scale[] = {NOTE_C4,NOTE_D4,NOTE_E4 };
//create a char array called instruct and store the message within it

DigitalOut seg1(PA_12); //seven segments;
DigitalOut seg2(PA_11);
DigitalOut seg3(PB_12);
DigitalOut seg4(PB_11);
DigitalOut seg5(PB_2);
DigitalOut seg6(PB_1);
DigitalOut seg7(PB_15);
DigitalOut seg8(PB_14);

BusOut SegDis(PA_11, PA_12, PB_1, PB_15,PB_14, PB_12, PB_11); //Add remaining pins in correct order
DigitalOut decimal_point(PB_2); //Add pin for the Decimal Point 

int hexDis[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F,0x67, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71 }; // Add the rest of the hex 4values associated with the dispplay items 0-F
int dp_status = 0;

float TEP_sensor=0.000;
float FSR_sensor=0.000;

#define BLINKING_RATE_busout   500ms

char INSTRUCT[] = "welcome to use washing machine system.\npress 'r' to start and press 'r' again to close the whole system \n" ;

//create a new array that will continually be erased and updated
char *INPUT = new char[1];

//declare functions
void init_led();//combination of leds.(include RGB)

void play_note(int frequency);

void SegDis_init();//for seven signment.
void SegDis_endcycle();//seven sigment

int main(){
    init_led(); //initialise led
    pc.write(INSTRUCT, sizeof(INSTRUCT));   //print instructions to terminal
    int count=0;//for the power on and off counting.
    int val=0; //the reminding in spin mode.
    int calculate=0;

    int cntl_val = 0;//these four commands are used to define the potentiometer related variable.
    int cntl_val0 = 0;
    int cntl_val1 = 0;
    int cntl_val2 = 0; 
    int cntl_val3 = 0;

    


    printf("please check the signal light.\n"
            "the system is setted to wishing mode by defalut.\n"
            "'red'stands for wishing mode,'green'stands for spin mode.\n"
            "if u want to return to the default setting, please click'x'\n"
            "if u wish to use spin mode, please click'g'.\n"
            "if u wish to close the system,just click r again\n");
    for(int i=1;i++;){
        
        if(pc.readable()){          //Check if any data are available to be read
            pc.read(INPUT, sizeof(INPUT));

            if (*INPUT == 'r' || *INPUT == 'R'){
                count++;
            }
              if((count+1)%2 == 0){//check wheter the power should be on or not, another part in line 404.
              printf("welcome to use the washing mode\n\n\n");
              redled.write(0.5);
              greenled.write(0);
              blueled.write(0);

              if(*INPUT == 'w' || *INPUT == 'W'){//condition to get into the washing mode.
              redled.write(1);
              greenled.write(0.125);
              blueled.write(0);
               
               for(val=0; val<=3; val++){
               leds_bus = 0b0001<<val;// Add code here to write 'val' to the bus. 
               ThisThread::sleep_for(100ms);   // Sleep for specified duration
               }
               for(val=0; val<=3; val++){
               leds_bus = 0b1000>>val;// Add code here to write 'val' to the bus. 
               ThisThread::sleep_for(100ms);// Sleep for specified duration
               }
               leds_bus.write(0);
                while(1){
                   if(pc.readable()){          //Check if any data are available to be read
                        pc.read(INPUT, sizeof(INPUT));
                        if(*INPUT == 'x' || *INPUT == 'X'){
                        leds_bus.write(0); //if input is equal to the char 'x' or 'X' , back to the default mode
                        break;
                        }
                    }
                    cntl_val = pot1.read_u16()/32768;
                    cntl_val1 = pot1.read_u16()/16384;
                    cntl_val2 = pot1.read_u16()/8192;
                    cntl_val0 = pot1.read_u16()/49152;
                    if(cntl_val0){leds_bus.write(0);}
                    else if(cntl_val){
                        leds_bus.write(1);
                        if(pc.readable()){          //Check if any data are available to be read
                        pc.read(INPUT, sizeof(INPUT));
                        if (*INPUT == 'z' || *INPUT == 'Z'){//press 'z' to start process
                            for(val=0; val<=1; val++){
                                if(button1.read() == 1)//code for accident avoid.
                                {
                                 return(0);
                                }
                                TEP_sensor=TMP.read()/(0.01);
                                FSR_sensor=FSR.read()*100;
                             


                                thread_sleep_for(100);
                                leds_bus = 0b0001>>val;
                                   if(FSR_sensor>=50||TEP_sensor>14){
                                   return(0); 
                                }//exit the whole system if the accident condition is met.
                                ThisThread::sleep_for(1000ms);
                                
                                }
                            }   leds_bus.write(0);
                                for(int i = 0; i < 4; i++){ 
                                    if (i ==3){
                                        break;
                                    }
                                    play_note(C_major_scale[i]);
                                }
                                buzzer.pulsewidth_us(0); 
                                printf("task complete.\n");//inform the user
                            if(*INPUT == 'x' || *INPUT == 'X'){//exit the system and back to the previous mode.
                            break;
                        }
                        }    
                    }
                    else if(cntl_val1){
                        leds_bus.write(3);
                        if(pc.readable()){          //Check if any data are available to be read
                        pc.read(INPUT, sizeof(INPUT));
                        if (*INPUT == 'z' || *INPUT == 'Z'){//press 'z' to start process
                            for(val=0; val<=2; val++){
                                if(button1.read() == 1)//code for accident avoid.
                                {
                                 return(0);
                                }
                                TEP_sensor=TMP.read()/(0.01);
                                FSR_sensor=FSR.read()*100;



                                thread_sleep_for(100);
                                leds_bus = 0b0011>>val;
                                if(FSR_sensor>=50||TEP_sensor>14){
                                   return(0); 
                                }//exit the whole system if the accident condition is met.
                                ThisThread::sleep_for(1000ms);
                                
                                }
                            }   leds_bus.write(0);
                                for(int i = 0; i < 4; i++){
                                    if (i ==3){
                                        break;
                                    } 
                                    play_note(C_major_scale[i]);
                                }
                                buzzer.pulsewidth_us(0); 
                                printf("Task complete.\n");//inform the user
                            if(*INPUT == 'x' || *INPUT == 'X'){//exit the system and back to the previous mode.
                            break;
                        }                       
                        }
                    }
                    else if(cntl_val2){
                        leds_bus.write(7);
                        if(pc.readable()){          //Check if any data are available to be read
                        pc.read(INPUT, sizeof(INPUT));
                        if (*INPUT == 'z' || *INPUT == 'Z'){//press 'z' to start process
                            for(val=0; val<=3; val++){
                                if(button1.read() == 1)//code for accident avoid.
                                {
                                 return(0);
                                }
                                TEP_sensor=TMP.read()/(0.01);
                                FSR_sensor=FSR.read()*100;


                                thread_sleep_for(100);
                                leds_bus = 0b0111>>val;
                                if(FSR_sensor>=50||TEP_sensor>14){
                                   return(0); 
                                }//exit the whole system if the accident condition is met.
                                ThisThread::sleep_for(1000ms);
                               
                                }
                                leds_bus.write(0);
                                for(int i = 0; i < 4; i++){  // for loop used to play the music.
                                     if (i ==3){
                                        break;
                                    }
                                    play_note(C_major_scale[i]);
                                }
                                buzzer.pulsewidth_us(0);
                                printf("Task complete.\n"); //inform the user

                            }
                            if(*INPUT == 'x' || *INPUT == 'X'){   //exit the system and back to the previous mode.
                            break;    
                        }
                        }
                    }

                    else{
                        leds_bus.write(15);
                        if(pc.readable()){          //Check if any data are available to be read
                        pc.read(INPUT, sizeof(INPUT));
                        if (*INPUT == 'z' || *INPUT == 'Z'){//press 'z' to start process
                            for(val=0; val<=4; val++){
                                if(button1.read() == 1)//code for accident avoid.
                                {
                                 return(0);
                                }
                                TEP_sensor=TMP.read()/(0.01);
                                FSR_sensor=FSR.read()*100;

                                thread_sleep_for(100);
                                leds_bus = 0b1111>>val;
               
                                if(FSR_sensor>=50||TEP_sensor>14){
                                   return(0); 
                                }//exit the whole system if the accident condition is met.
                                
                                ThisThread::sleep_for(1000ms);
                                        
                                }
                                leds_bus.write(0); 
                                 for(int i = 0; i < 4; i++){
                                     if (i ==3){
                                        break;
                                    } 
                                    play_note(C_major_scale[i]);
                                                                       
                                }
                                buzzer.pulsewidth_us(0);
                                printf("Task complete.\n");//inform the user      
                            }
                            if(*INPUT == 'x' || *INPUT == 'X'){//exit the system and back to the previous mode.
                            break;
                        }
                        }
                    }              
               }
            }
            
            
            if(*INPUT == 'g' || *INPUT == 'G'){//the condition of getting in the spining mode
              printf("welcome to use spin mode\n");
              redled.write(0);
              greenled.write(0.5);
              blueled.write(0);  
              printf("please select the speed you perfer\n");
              printf("you can use the key board to control the time\n");

            for(val=0; val<=3; val++){
            leds_bus = 0b0001<<val;// Add code here to write 'val' to the bus. 
            ThisThread::sleep_for(100ms);   // Sleep for specified duration
            }
            for(val=0; val<=3; val++){
            leds_bus = 0b1000>>val;// Add code here to write 'val' to the bus. 
            ThisThread::sleep_for(100ms);
               // Sleep for specified duration
            }
            leds_bus.write(0);
            while(1){
                pc.read(INPUT, sizeof(INPUT));
                if(*INPUT == 'x' || *INPUT == 'X'){
                SegDis.write(0x00); //if input is equal to the char 'x' or 'X' , reset all states to 0
                break;
                }   
                while(*INPUT == 's' || *INPUT == 'S'){
                pc.read(INPUT, sizeof(INPUT));
                SegDis.write(hexDis[9]);
                decimal_point.write(dp_status); //write value to decimal point
                dp_status = !dp_status;         //toggle decimal point on/off
               
                    while(1){
                            if(pc.readable()){          //Check if any data are available to be read
                            pc.read(INPUT, sizeof(INPUT));
                            if(*INPUT == 'x' || *INPUT == 'X'){
                            SegDis.write(0x00); //if input is equal to the char 'x' or 'X' , reset all states to 0
                            break;
                            }
                            if(*INPUT == 'z' || *INPUT == 'Z'){
                            for(int i = 9; i >=0; i--){        //count down the duration of the spining time.
                            SegDis.write(hexDis[i]);
                            decimal_point.write(dp_status); //write value to decimal point
                            dp_status = !dp_status;         //toggle decimal point on/off

                            ThisThread::sleep_for(500ms);
                            
                            
                            }
                            printf("task complete.\n");
                            }               

                            }                     
                            }
               
             }
             while(*INPUT == 'm' || *INPUT == 'M'){
               SegDis.write(hexDis[7]);
               decimal_point.write(dp_status); //write value to decimal point
               dp_status = !dp_status;         //toggle decimal point on/off
                    while(1){
                            if(pc.readable()){          //Check if any data are available to be read
                            pc.read(INPUT, sizeof(INPUT));
                            if(*INPUT == 'x' || *INPUT == 'X'){
                            SegDis.write(0x00); //if input is equal to the char 'x' or 'X' , reset all states to 0
                            break;
                            }
                            if(*INPUT == 'z' || *INPUT == 'Z'){
                            for(int i = 7; i >=0; i--){       //count down the duration of the spining time.
                            SegDis.write(hexDis[i]);
                            decimal_point.write(dp_status); //write value to decimal point
                            dp_status = !dp_status;         //toggle decimal point on/off

                            ThisThread::sleep_for(500ms);
                            
                            
                            }
                            printf("task complete.\n");
                            }               

                            }                     
                            }
             }

             while(*INPUT == 'f' || *INPUT == 'F'){
               SegDis.write(hexDis[4]);
               decimal_point.write(dp_status); 
               dp_status = !dp_status;         
                        while(1){
                            if(pc.readable()){          
                            pc.read(INPUT, sizeof(INPUT));
                            if(*INPUT == 'x' || *INPUT == 'X'){
                            SegDis.write(0x00); //if input is equal to the char 'x' or 'X' , reset all states to 0
                            break;
                            }
                            if(*INPUT == 'z' || *INPUT == 'Z'){
                            for(int i = 4; i >=0; i--){      //count down the duration of the spining time.
                            SegDis.write(hexDis[i]);
                            decimal_point.write(dp_status); //write value to decimal point
                            dp_status = !dp_status;         //toggle decimal point on/off

                            ThisThread::sleep_for(500ms);
                                                       
                            }
                            printf("task complete.\n");
                            }               

                            }                     
                            }
             }


            }
               
            }   
           
        }
            
    }             
        else if((count+1)%2 == 1){
                    redled.write(0);
                    greenled.write(0);
                    blueled.write(0);
   
                }
        else if(*INPUT == 'x' || *INPUT == 'X'){ //if input is equal to the char 'x' or 'X' , reset all states to 0
                init_led();
                }
        else{                          //default condition, maintain current states.
               
            }
            
              //read the users input and store it in char array called INPUT
            
        }
     thread_sleep_for(100); 

    }

void init_led(){
    //default states for RGB LED (red ON full at 50%, green OFF, blue OFF)
    redled.write(0);
    greenled.write(0);
    blueled.write(0);
    leds_bus.write(0);
}

void play_note(int frequency){
    buzzer.period_us((float) 1000000.0f/ (float) frequency);    //set the period of the pwm signal (in us)
    buzzer.pulsewidth_us(buzzer.read_period_us()/2);            //set pulse width of the pwm to 1/2 the period
    ThisThread::sleep_for(500ms);                               //play sound for 500ms
}

void SegDis_init(){
    SegDis.write(0x00); //turn off the display by setting all segments to '0'
    ThisThread::sleep_for(50ms);
}
